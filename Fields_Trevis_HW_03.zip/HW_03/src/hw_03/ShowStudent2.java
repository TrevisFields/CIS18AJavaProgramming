
package hw_03;

public class ShowStudent2
	{
		public static void main(String[] args)
			{
				Student info = new Student();
				
                                System.out.println(info.displayInfo());
			}
	}
